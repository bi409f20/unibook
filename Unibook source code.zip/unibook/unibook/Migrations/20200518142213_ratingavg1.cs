﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace unibook.Migrations
{
    public partial class ratingavg1 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
