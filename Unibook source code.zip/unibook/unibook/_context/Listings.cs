﻿namespace _context
{
    internal class Listings
    {
    }
}